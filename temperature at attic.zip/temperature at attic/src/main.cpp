#include <Arduino.h>
#include <OneWire.h>
#include <DallasTemperature.h>
#include <ThingSpeak.h>
#include <WiFiManager.h>
 
# define ledka 13
#define one_wire_bus 12
OneWire onevirebus(one_wire_bus);
DallasTemperature sensor(&onevirebus);
const char* ssid = "*********";
const char* password = "*********";


void printAddress(DeviceAddress deviceAddress);


WiFiClient KLIENT;
unsigned long myChannelNumber = 1;
const char * myWriteAPIKey = "********";

unsigned long lastTime = 0;
unsigned long timerDelay = 30000;

float Temperature;
int numberofdevices;
DeviceAddress tempdeviceadresa;

void setup() {
Serial.begin(115200);
pinMode(ledka, OUTPUT);
sensor.begin();
numberofdevices = sensor.getDeviceCount();
Serial.print("počet čidel je:");
Serial.println(numberofdevices);

  for(int i=0;i<numberofdevices; i++){
    // Search the wire for address
    if(sensor.getAddress(tempdeviceadresa, i)){
      Serial.print("Found device ");
      Serial.print(i, DEC);
      Serial.print(" with address: ");
      printAddress(tempdeviceadresa);
      Serial.println();
    } else {
      Serial.print("Found ghost device at ");
      Serial.print(i, DEC);
      Serial.print(" but could not detect address. Check power and cabling");
    }
  }

  delay(5000);

WiFi.mode(WIFI_STA);
ThingSpeak.begin(KLIENT);
 
    Serial.println("");
    Serial.println("WiFi connected");
    Serial.println("IP address: ");
    Serial.println(WiFi.localIP());
    Serial.println();
   
}

void loop() {
  
  if ((millis()-lastTime) > timerDelay){
    if(WiFi.status() !=  WL_CONNECTED){
      Serial.print( "pokouším se připojit");
       while(WiFi.status() != WL_CONNECTED){
        WiFi.begin(ssid, password); 
        delay(5000);    
       }
    Serial.println("\nConnected");
   digitalWrite(ledka,HIGH);
    }
    
sensor.requestTemperatures();
Temperature = sensor.getTempCByIndex(0);
Serial.print("teplota");
Serial.println(Temperature);

int x = ThingSpeak.writeField(myChannelNumber, 1, Temperature, myWriteAPIKey);
if(x == 200){
Serial.println("channel was update successfuly");
}
else{
Serial.println("Problem updating channel. HTTP error code " + String(x));
      }
lastTime = millis();
  }
  
}
 

void printAddress(DeviceAddress deviceAddress) {
  for (uint8_t i = 0; i < 8; i++){
    if (deviceAddress[i] < 16) Serial.print("0");
      Serial.print(deviceAddress[i], HEX);
  }
}
