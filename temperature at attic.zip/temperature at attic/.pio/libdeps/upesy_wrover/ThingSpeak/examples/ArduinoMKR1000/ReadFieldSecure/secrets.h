// Use this file to store all of the private credentials 
// and connection details

#define SECRET_SSID "MySSID"		// replace MySSID with your WiFi network name
#define SECRET_PASS "MyPassword"	// replace MyPassword with your WiFi password

#define SECRET_CH_ID_WEATHER_STATION 12397	          	//MathWorks weather station

#define SECRET_CH_ID_COUNTER 298725 					//Test channel for counting
#define SECRET_READ_APIKEY_COUNTER "SODG0O2UZVGKWAWG"	//API Key for Test channel
